# fastapi-creation

A simple package to create FastAPI project layouts easily.
